package com.xereztap.panel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val Navy=Color(0xFF0B1220)
private val Gold=Color(0xFFD6A84A)
private val Bg=Color(0xFFF5F7FA)

data class Business(val name:String,val category:String,val reviews:Int,val scans:Int)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}
}

@Composable fun App(){
 var page by remember{mutableStateOf("Inicio")}
 var businesses by remember{mutableStateOf(listOf(
  Business("Bodega Demo","Bodega",128,842),
  Business("Bar Centro","Hostelería",74,513),
  Business("Hotel Jerez","Hotel",211,1290)
 ))}
 Scaffold(
  topBar={TopAppBar(title={Column{
   Text("XerezTap",fontWeight=FontWeight.Bold)
   Text("Panel de control",fontSize=12.sp)
  }},colors=TopAppBarDefaults.topAppBarColors(containerColor=Navy,titleContentColor=Color.White))},
  bottomBar={NavigationBar{
   listOf("Inicio","Negocios","Estadísticas","Ajustes").forEach{p->
    NavigationBarItem(selected=page==p,onClick={page=p},
     icon={Icon(when(p){"Inicio"->Icons.Default.Home;"Negocios"->Icons.Default.Store;"Estadísticas"->Icons.Default.BarChart;else->Icons.Default.Settings},null)},
     label={Text(p)})
   }
  }}
 ){pad->Box(Modifier.padding(pad).fillMaxSize()){
  when(page){
   "Inicio"->Home(businesses)
   "Negocios"->Businesses(businesses){businesses=businesses+Business("Nuevo negocio ${businesses.size+1}","Sin categoría",0,0)}
   "Estadísticas"->Stats(businesses)
   else->Settings()
  }
 }}
}

@Composable fun Home(b:List<Business>){
 LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  item{Text("Dashboard",fontSize=28.sp,fontWeight=FontWeight.Bold);Text("Gestiona XerezTap desde tu móvil.",color=Color.Gray)}
  item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
   Card(Modifier.weight(1f)){Column(Modifier.padding(16.dp)){Icon(Icons.Default.Store,null,tint=Gold);Text(b.size.toString(),fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Negocios")}}
   Card(Modifier.weight(1f)){Column(Modifier.padding(16.dp)){Icon(Icons.Default.QrCode2,null,tint=Gold);Text(b.sumOf{it.scans}.toString(),fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Escaneos")}}
  }}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Reseñas generadas",fontWeight=FontWeight.Bold);Text(b.sumOf{it.reviews}.toString(),fontSize=30.sp)}}}
 }
}

@Composable fun Businesses(b:List<Business>,add:()->Unit){
 Column(Modifier.fillMaxSize().background(Bg)){
  Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
   Text("Negocios",fontSize=27.sp,fontWeight=FontWeight.Bold)
   FloatingActionButton(onClick=add,containerColor=Navy){Icon(Icons.Default.Add,null,tint=Color.White)}
  }
  LazyColumn(Modifier.padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   items(b){x->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){
    Icon(Icons.Default.Store,null,tint=Gold,modifier=Modifier.size(38.dp));Spacer(Modifier.width(12.dp))
    Column(Modifier.weight(1f)){Text(x.name,fontWeight=FontWeight.Bold,fontSize=18.sp);Text(x.category,color=Color.Gray);Text("${x.scans} escaneos · ${x.reviews} reseñas",fontSize=12.sp)}
    Icon(Icons.Default.CheckCircle,null,tint=Color(0xFF2E7D32))
   }}}
  }
 }
}

@Composable fun Stats(b:List<Business>){
 Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  Text("Estadísticas",fontSize=27.sp,fontWeight=FontWeight.Bold)
  Text("Resumen de todos los negocios",color=Color.Gray)
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Escaneos",fontWeight=FontWeight.Bold);Text(b.sumOf{it.scans}.toString(),fontSize=32.sp)}}
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Reseñas",fontWeight=FontWeight.Bold);Text(b.sumOf{it.reviews}.toString(),fontSize=32.sp)}}
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Próximamente",fontWeight=FontWeight.Bold);Text("Gráficas por día, semana y mes, conectadas a la API PHP.")}}
 }
}

@Composable fun Settings(){
 Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  Text("Ajustes",fontSize=27.sp,fontWeight=FontWeight.Bold)
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Cuenta administrador",fontWeight=FontWeight.Bold);Text("Panel XerezTap",color=Color.Gray)}}
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Servidor",fontWeight=FontWeight.Bold);Text("xereztap.myartsonline.com",color=Color.Gray)}}
 }
}
