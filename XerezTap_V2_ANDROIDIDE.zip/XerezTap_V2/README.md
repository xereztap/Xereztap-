# XerezTap Android V2

Aplicación Android independiente para XerezTap. No es una web envuelta en una app.

Incluye:
- Inicio y navegación inferior.
- Catálogo de negocios y búsqueda.
- Favoritos en memoria durante la sesión.
- Ficha de negocio.
- Escáner QR mediante ZXing.
- Apertura de fichas mediante enlaces HTTPS/QR/NFC.
- Backend PHP de demostración preparado para conectar con AwardSpace.

## Compilación
Abrir en Android Studio y sincronizar Gradle. El entorno de esta sesión no dispone de Android SDK/Gradle descargable, por lo que no se ha generado aquí un APK binario firmado.

## Siguiente integración de producción
1. Sustituir datos demo por MySQL/API.
2. Conectar el listado y fichas a `web/api.php`.
3. Añadir administración de negocios, promociones y estadísticas.
4. Generar QR/NFC por slug estable.
5. Añadir login de administración y publicación.
