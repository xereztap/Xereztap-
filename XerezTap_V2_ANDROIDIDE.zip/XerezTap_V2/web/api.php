<?php
header('Content-Type: application/json; charset=utf-8');
$slug = isset($_GET['slug']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['slug']) : '';
$businesses = [
 'bodega-demo'=>['slug'=>'bodega-demo','name'=>'Bodega Demo','category'=>'Bodegas','description'=>'Descubre vinos y experiencias de Jerez.','address'=>'Jerez de la Frontera','rating'=>4.8,'reviews'=>126],
 'varon-demo'=>['slug'=>'varon-demo','name'=>'Varón Demo','category'=>'Restauración','description'=>'Gastronomía, ambiente y producto local.','address'=>'Jerez de la Frontera','rating'=>4.7,'reviews'=>94],
 'comercio-demo'=>['slug'=>'comercio-demo','name'=>'Comercio Demo','category'=>'Comercios','description'=>'Ejemplo de ficha digital XerezTap para comercios.','address'=>'Centro de Jerez','rating'=>4.6,'reviews'=>51],
 'servicio-demo'=>['slug'=>'servicio-demo','name'=>'Servicio Demo','category'=>'Servicios','description'=>'Profesionales locales con información siempre actualizada.','address'=>'Jerez de la Frontera','rating'=>4.9,'reviews'=>73]
];
if ($slug !== '' && isset($businesses[$slug])) { echo json_encode(['ok'=>true,'business'=>$businesses[$slug]], JSON_UNESCAPED_UNICODE); exit; }
echo json_encode(['ok'=>true,'businesses'=>array_values($businesses)], JSON_UNESCAPED_UNICODE);
