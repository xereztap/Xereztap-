package com.xereztap.app

import android.content.Intent
import android.net.Uri
import android.nfc.NfcAdapter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

private val Brand = Color(0xFF0E4D64)
private val Accent = Color(0xFFE2A72E)

data class Business(
    val slug: String,
    val name: String,
    val category: String,
    val description: String,
    val address: String,
    val rating: Double,
    val reviews: Int,
    val phone: String = "",
    val website: String = ""
)

private val businesses = listOf(
    Business("bodega-demo", "Bodega Demo", "Bodegas", "Descubre vinos y experiencias de Jerez.", "Jerez de la Frontera", 4.8, 126),
    Business("varon-demo", "Varón Demo", "Restauración", "Gastronomía, ambiente y producto local.", "Jerez de la Frontera", 4.7, 94),
    Business("comercio-demo", "Comercio Demo", "Comercios", "Ejemplo de ficha digital XerezTap para comercios.", "Centro de Jerez", 4.6, 51),
    Business("servicio-demo", "Servicio Demo", "Servicios", "Profesionales locales con información siempre actualizada.", "Jerez de la Frontera", 4.9, 73)
)

class MainActivity : ComponentActivity() {
    private var deepLinkSlug by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        deepLinkSlug = extractSlug(intent)
        setContent { XerezTapApp(deepLinkSlug) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        deepLinkSlug = extractSlug(intent)
    }

    private fun extractSlug(intent: Intent?): String? {
        val uri = intent?.data ?: return null
        if (uri.host != "xereztap.myartsonline.com") return null
        return uri.getQueryParameter("slug")
            ?: uri.pathSegments.firstOrNull { it.isNotBlank() }
    }
}

@Composable
fun XerezTapApp(initialSlug: String?) {
    val nav = rememberNavController()
    val favorites = remember { mutableStateListOf<String>() }
    val start = if (initialSlug != null) "business/$initialSlug" else "home"
    MaterialTheme(colorScheme = lightColorScheme(primary = Brand, secondary = Accent)) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavItem(nav, "home", "Inicio", Icons.Filled.Home)
                    NavItem(nav, "businesses", "Negocios", Icons.Filled.Storefront)
                    NavItem(nav, "favorites", "Favoritos", Icons.Filled.Favorite)
                }
            }
        ) { padding ->
            NavHost(nav, startDestination = start, modifier = Modifier.padding(padding)) {
                composable("home") { HomeScreen(nav) }
                composable("businesses") { BusinessListScreen(nav) }
                composable("favorites") {
                    val list = businesses.filter { it.slug in favorites }
                    BusinessListScreen(nav, title = "Mis favoritos", source = list, empty = "Todavía no tienes negocios guardados.")
                }
                composable("business/{slug}", arguments = listOf(navArgument("slug") { type = NavType.StringType })) { back ->
                    val slug = back.arguments?.getString("slug") ?: ""
                    businesses.firstOrNull { it.slug == slug }?.let { b ->
                        BusinessDetailScreen(b, favorites.contains(b.slug)) { add ->
                            if (add) favorites.add(b.slug) else favorites.remove(b.slug)
                        }
                    } ?: SimpleScreen("Negocio no encontrado", "El identificador no corresponde a un negocio publicado en XerezTap.")
                }
            }
        }
    }
}

@Composable
private fun NavItem(nav: NavHostController, route: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val selected = nav.currentBackStackEntryAsState().value?.destination?.route == route
    NavigationBarItem(selected = selected, onClick = {
        nav.navigate(route) { popUpTo("home"); launchSingleTop = true }
    }, icon = { Icon(icon, null) }, label = { Text(label) })
}

@Composable
fun HomeScreen(nav: NavHostController) {
    val scanner = rememberLauncherForActivityResult(ScanContract()) { result ->
        val value = result.contents ?: return@rememberLauncherForActivityResult
        val uri = runCatching { Uri.parse(value) }.getOrNull()
        val slug = uri?.getQueryParameter("slug") ?: uri?.pathSegments?.lastOrNull()
        if (!slug.isNullOrBlank()) nav.navigate("business/$slug")
    }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Brand, RoundedCornerShape(24.dp)).padding(22.dp)) {
                Text("XerezTap", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Descubre Jerez. Conecta con sus negocios.", color = Color.White.copy(alpha = .9f), fontSize = 16.sp)
            }
        }
        item {
            OutlinedTextField(value = "", onValueChange = {}, enabled = false, modifier = Modifier.fillMaxWidth(), leadingIcon = { Icon(Icons.Filled.Search, null) }, placeholder = { Text("Buscar negocios") })
        }
        item {
            Button(onClick = { scanner.launch(ScanOptions().apply { setDesiredBarcodeFormats(ScanOptions.QR_CODE); setPrompt("Escanea el QR de XerezTap") }) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Filled.QrCodeScanner, null); Spacer(Modifier.width(8.dp)); Text("Escanear QR")
            }
        }
        item { Text("Categorías", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(listOf("Restauración", "Bodegas", "Comercios", "Servicios")) { category ->
            Card(Modifier.fillMaxWidth().clickable { nav.navigate("businesses") }, shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Storefront, null, tint = Brand)
                    Spacer(Modifier.width(14.dp)); Text(category, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun BusinessListScreen(nav: NavHostController, title: String = "Negocios", source: List<Business> = businesses, empty: String = "No hay negocios disponibles.") {
    var query by remember { mutableStateOf("") }
    val filtered = source.filter { it.name.contains(query, true) || it.category.contains(query, true) }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Buscar") }, leadingIcon = { Icon(Icons.Filled.Search, null) })
        }
        if (filtered.isEmpty()) item { Text(empty, Modifier.padding(vertical = 20.dp)) }
        items(filtered) { b ->
            Card(Modifier.fillMaxWidth().clickable { nav.navigate("business/${b.slug}") }, shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text(b.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(b.category, color = Brand)
                    Spacer(Modifier.height(6.dp))
                    Text(b.description, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("★ ${b.rating}", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(10.dp)); Text("${b.reviews} reseñas")
                    }
                }
            }
        }
    }
}

@Composable
fun BusinessDetailScreen(b: Business, favorite: Boolean, onFavorite: (Boolean) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = Brand, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(24.dp)) {
                    Text(b.name, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(b.category, color = Color.White.copy(.85f))
                    Spacer(Modifier.height(12.dp))
                    Text("★ ${b.rating}  ·  ${b.reviews} reseñas", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item { Text(b.description, style = MaterialTheme.typography.bodyLarge) }
        item { InfoRow(Icons.Filled.Place, b.address) }
        item {
            Button(onClick = { onFavorite(!favorite) }, modifier = Modifier.fillMaxWidth()) {
                Icon(if (favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null)
                Spacer(Modifier.width(8.dp)); Text(if (favorite) "Guardado en favoritos" else "Guardar en favoritos")
            }
        }
        item {
            OutlinedButton(onClick = {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://xereztap.myartsonline.com/?slug=${b.slug}")))
            }, modifier = Modifier.fillMaxWidth()) { Text("Abrir ficha online") }
        }
        item {
            Text("XerezTap QR + NFC", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("La placa física puede conservar el mismo identificador aunque cambies fotos, horarios, promociones o datos del negocio en el servidor.")
        }
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Brand); Spacer(Modifier.width(10.dp)); Text(text) }
}

@Composable
fun SimpleScreen(title: String, body: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text(title, style = MaterialTheme.typography.headlineMedium); Text(body) }
}
