package com.xereztap.panel

import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Navy = Color(0xFF0B1220)
private val Gold = Color(0xFFD6A84A)
private val Bg = Color(0xFFF5F7FA)

data class Business(
    val id: String,
    val slug: String,
    val name: String,
    val category: String,
    val address: String,
    val phone: String,
    val whatsapp: String,
    val instagram: String,
    val website: String,
    val googleReview: String,
    val scans: Int,
    val reviews: Int,
    val active: Boolean
)

data class ApiResult(val ok: Boolean, val json: JSONObject?, val error: String = "")

class MainActivity : ComponentActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private var writingUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        setContent { App(this) }
    }

    fun startNfcWrite(url: String) {
        writingUrl = url
        val adapter = nfcAdapter
        if (adapter == null) {
            Toast.makeText(this, "Este móvil no tiene NFC", Toast.LENGTH_LONG).show()
            return
        }
        if (!adapter.isEnabled) {
            startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
            return
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_MUTABLE
        )
        adapter.enableForegroundDispatch(this, pendingIntent, null, null)
        Toast.makeText(this, "Acerca la placa o tarjeta NFC al móvil", Toast.LENGTH_LONG).show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val tag = intent.getParcelableExtra<android.nfc.Tag>(NfcAdapter.EXTRA_TAG) ?: return
        val url = writingUrl ?: return
        try {
            val ndef = android.nfc.tech.Ndef.get(tag)
            if (ndef == null) throw IllegalStateException("La etiqueta no admite NDEF")
            ndef.connect()
            ndef.writeNdefMessage(NdefMessage(arrayOf(NdefRecord.createUri(url))))
            ndef.close()
            Toast.makeText(this, "NFC configurado correctamente", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo escribir el NFC: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            nfcAdapter?.disableForegroundDispatch(this)
            writingUrl = null
        }
    }

    fun showQr(url: String) {
        try {
            val matrix = MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, 900, 900)
            val bitmap = Bitmap.createBitmap(900, 900, Bitmap.Config.ARGB_8888)
            for (x in 0 until 900) {
                for (y in 0 until 900) {
                    bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
                }
            }
            val image = ImageView(this).apply {
                setImageBitmap(bitmap)
                setPadding(24, 24, 24, 8)
                adjustViewBounds = true
            }
            AlertDialog.Builder(this)
                .setTitle("QR de XerezTap")
                .setMessage(url)
                .setView(image)
                .setPositiveButton("Cerrar", null)
                .show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo generar el QR: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}

object Api {
    var baseUrl = "https://xereztap.myartsonline.com/api.php"
    var token = ""

    private fun request(method: String, action: String, body: String = ""): ApiResult = try {
        val authParam = if (token.isNotBlank()) "&token=${URLEncoder.encode(token, "UTF-8")}" else ""
        val url = URL("$baseUrl?action=${URLEncoder.encode(action, "UTF-8")}$authParam")
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        if (token.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $token")
        if (body.isNotBlank()) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        val json = JSONObject(text)
        ApiResult(json.optBoolean("ok"), json, json.optString("error"))
    } catch (e: Exception) {
        ApiResult(false, null, e.message ?: "Error de conexión")
    }

    fun login(email: String, password: String) = request("POST", "login", JSONObject().apply {
        put("email", email)
        put("password", password)
    }.toString())

    fun businesses() = request("GET", "businesses")
    fun save(b: JSONObject) = request("POST", "save_business", b.toString())
    fun delete(id: String) = request("POST", "delete_business", JSONObject().put("id", id).toString())
    fun stats() = request("GET", "stats")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(activity: MainActivity) {
    var logged by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("Inicio") }
    var businesses by remember { mutableStateOf<List<Business>>(emptyList()) }
    var selected by remember { mutableStateOf<Business?>(null) }
    var editing by remember { mutableStateOf<Business?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    fun refresh() {
        loading = true
        CoroutineScope(Dispatchers.IO).launch {
            val r = Api.businesses()
            val list = if (r.ok) parseBusinesses(r.json) else emptyList()
            withContext(Dispatchers.Main) {
                businesses = list
                error = r.error
                loading = false
            }
        }
    }

    if (!logged) {
        Login(
            onLogin = { email, pwd ->
                loading = true
                CoroutineScope(Dispatchers.IO).launch {
                    val r = Api.login(email, pwd)
                    withContext(Dispatchers.Main) {
                        loading = false
                        if (r.ok) {
                            Api.token = r.json?.optString("token", "") ?: ""
                            logged = true
                            refresh()
                        } else error = r.error
                    }
                }
            },
            loading = loading,
            error = error
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("XerezTap", fontWeight = FontWeight.Bold)
                        Text("Panel de control", fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Navy,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Inicio", "Negocios", "Estadísticas", "Ajustes").forEach { p ->
                    NavigationBarItem(
                        selected = page == p,
                        onClick = { page = p },
                        icon = {
                            Icon(
                                when (p) {
                                    "Inicio" -> Icons.Default.Home
                                    "Negocios" -> Icons.Default.Store
                                    "Estadísticas" -> Icons.Default.BarChart
                                    else -> Icons.Default.Settings
                                }, null
                            )
                        },
                        label = { Text(p) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                selected != null -> BusinessDetail(
                    selected!!,
                    { selected = null },
                    { url -> activity.startNfcWrite(url) },
                    { url -> activity.showQr(url) }
                )
                editing != null -> BusinessForm(
                    editing!!,
                    { editing = null },
                    { json ->
                        loading = true
                        CoroutineScope(Dispatchers.IO).launch {
                            val r = Api.save(json)
                            withContext(Dispatchers.Main) {
                                loading = false
                                if (r.ok) {
                                    editing = null
                                    refresh()
                                } else error = r.error
                            }
                        }
                    }
                )
                page == "Inicio" -> Home(businesses, loading)
                page == "Negocios" -> Businesses(
                    businesses,
                    { editing = emptyBusiness() },
                    { selected = it },
                    { editing = it }
                )
                page == "Estadísticas" -> Stats(businesses)
                else -> SettingsScreen { Api.baseUrl = it }
            }
        }
    }

    if (error.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { error = "" },
            confirmButton = { TextButton(onClick = { error = "" }) { Text("OK") } },
            title = { Text("XerezTap") },
            text = { Text(error) }
        )
    }
}

fun emptyBusiness() = Business("", "", "", "", "", "", "", "", "", "", 0, 0, true)

fun parseBusinesses(j: JSONObject?): List<Business> {
    val a = j?.optJSONArray("businesses") ?: JSONArray()
    return (0 until a.length()).map { i ->
        val x = a.getJSONObject(i)
        Business(
            x.optString("id"), x.optString("slug"), x.optString("name"), x.optString("category"),
            x.optString("address"), x.optString("phone"), x.optString("whatsapp"), x.optString("instagram"),
            x.optString("website"), x.optString("google_review"), x.optInt("scans"), x.optInt("reviews"),
            x.optBoolean("active", true)
        )
    }
}

@Composable
fun Login(onLogin: (String, String) -> Unit, loading: Boolean, error: String) {
    var email by remember { mutableStateOf("") }
    var pwd by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().background(Navy).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("XT", fontSize = 62.sp, fontWeight = FontWeight.Black, color = Gold)
        Text("XerezTap", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("PANEL DE CONTROL", color = Color.LightGray)
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pwd, { pwd = it }, label = { Text("Contraseña") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        Button(onClick = { onLogin(email, pwd) }, enabled = !loading && email.isNotBlank() && pwd.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text(if (loading) "Conectando…" else "Entrar")
        }
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(error, color = Color(0xFFFFB4AB))
        }
    }
}

@Composable
fun Home(b: List<Business>, loading: Boolean) {
    val scans = b.sumOf { it.scans }
    val reviews = b.sumOf { it.reviews }
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Dashboard", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Resumen de XerezTap", color = Color.Gray) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Metric("Negocios", b.size.toString(), Icons.Default.Store, Modifier.weight(1f)); Metric("Escaneos", scans.toString(), Icons.Default.QrCode2, Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Metric("Reseñas", reviews.toString(), Icons.Default.Star, Modifier.weight(1f)); Metric("Activos", b.count { it.active }.toString(), Icons.Default.CheckCircle, Modifier.weight(1f)) } }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("Actividad", fontWeight = FontWeight.Bold); Text(if (loading) "Actualizando…" else "Datos sincronizados con el servidor PHP.", color = Color.Gray) } } }
    }
}

@Composable
fun Metric(t: String, v: String, icon: androidx.compose.ui.graphics.vector.ImageVector, m: Modifier) {
    Card(m) { Column(Modifier.padding(16.dp)) { Icon(icon, null, tint = Gold); Text(v, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text(t, color = Color.Gray) } }
}

@Composable
fun Businesses(b: List<Business>, add: () -> Unit, open: (Business) -> Unit, edit: (Business) -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("Negocios", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Gestiona tus clientes", color = Color.Gray) }
            FloatingActionButton(onClick = add, containerColor = Navy) { Icon(Icons.Default.Add, null, tint = Color.White) }
        }
        LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(b) { x ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Store, null, tint = Gold, modifier = Modifier.size(38.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(x.name.ifBlank { "Sin nombre" }, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(x.category.ifBlank { "Sin categoría" }, color = Color.Gray)
                            Text("${x.scans} escaneos · ${x.reviews} reseñas", fontSize = 12.sp)
                        }
                        IconButton(onClick = { open(x) }) { Icon(Icons.Default.Visibility, null) }
                        IconButton(onClick = { edit(x) }) { Icon(Icons.Default.Edit, null) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusinessDetail(b: Business, back: () -> Unit, nfc: (String) -> Unit, qr: (String) -> Unit) {
    val url = "https://xereztap.myartsonline.com/?slug=${b.slug}"
    Column(Modifier.fillMaxSize().background(Bg)) {
        TopAppBar(title = { Text(b.name.ifBlank { "Negocio" }) }, navigationIcon = { IconButton(back) { Icon(Icons.Default.ArrowBack, null) } })
        LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(b.category, fontWeight = FontWeight.Bold); Text(b.address); Text(b.phone) } } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Metric("Escaneos", b.scans.toString(), Icons.Default.QrCode2, Modifier.weight(1f)); Metric("Reseñas", b.reviews.toString(), Icons.Default.Star, Modifier.weight(1f)) } }
            item { Text("Enlaces", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
            item { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text("Google: ${b.googleReview.ifBlank { "—" }}"); Text("WhatsApp: ${b.whatsapp.ifBlank { "—" }}"); Text("Instagram: ${b.instagram.ifBlank { "—" }}"); Text("Web: ${b.website.ifBlank { "—" }}") } }
            item { Button(onClick = { qr(url) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.QrCode2, null); Spacer(Modifier.width(8.dp)); Text("Ver / generar QR") } }
            item { Button(onClick = { nfc(url) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Nfc, null); Spacer(Modifier.width(8.dp)); Text("Configurar NFC") } }
        }
    }
}

@Composable
fun BusinessForm(b: Business, back: () -> Unit, save: (JSONObject) -> Unit) {
    var name by remember { mutableStateOf(b.name) }
    var slug by remember { mutableStateOf(b.slug) }
    var cat by remember { mutableStateOf(b.category) }
    var address by remember { mutableStateOf(b.address) }
    var phone by remember { mutableStateOf(b.phone) }
    var wa by remember { mutableStateOf(b.whatsapp) }
    var ig by remember { mutableStateOf(b.instagram) }
    var web by remember { mutableStateOf(b.website) }
    var google by remember { mutableStateOf(b.googleReview) }
    var active by remember { mutableStateOf(b.active) }

    @Composable fun field(label: String, value: String, set: (String) -> Unit) {
        OutlinedTextField(value, set, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopAppBar(title = { Text(if (b.id.isBlank()) "Añadir negocio" else "Editar negocio") }, navigationIcon = { IconButton(back) { Icon(Icons.Default.ArrowBack, null) } })
        LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            item { field("Nombre", name) { name = it } }
            item { field("Slug", slug) { slug = it } }
            item { field("Categoría", cat) { cat = it } }
            item { field("Dirección", address) { address = it } }
            item { field("Teléfono", phone) { phone = it } }
            item { field("WhatsApp", wa) { wa = it } }
            item { field("Instagram", ig) { ig = it } }
            item { field("Web", web) { web = it } }
            item { field("URL Google Reviews", google) { google = it } }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Activo"); Spacer(Modifier.weight(1f)); Switch(checked = active, onCheckedChange = { active = it }) } }
            item {
                Button(onClick = {
                    save(JSONObject().apply {
                        if (b.id.isNotBlank()) put("id", b.id)
                        put("name", name); put("slug", slug); put("category", cat); put("address", address)
                        put("phone", phone); put("whatsapp", wa); put("instagram", ig); put("website", web)
                        put("google_review", google); put("active", active)
                    })
                }, modifier = Modifier.fillMaxWidth()) { Text("Guardar negocio") }
            }
        }
    }
}

@Composable
fun Stats(b: List<Business>) {
    val scans = b.sumOf { it.scans }
    val reviews = b.sumOf { it.reviews }
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Estadísticas", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Todos los negocios", color = Color.Gray) }
        item { Metric("Escaneos", scans.toString(), Icons.Default.QrCode2, Modifier.fillMaxWidth()) }
        item { Metric("Reseñas", reviews.toString(), Icons.Default.Star, Modifier.fillMaxWidth()) }
        item { Text("Rendimiento por negocio", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(b.sortedByDescending { it.scans }) { x -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(x.name, Modifier.weight(1f), fontWeight = FontWeight.Bold); Text("${x.scans} / ${x.reviews}") } } }
    }
}

@Composable
fun SettingsScreen(save: (String) -> Unit) {
    var url by remember { mutableStateOf(Api.baseUrl) }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ajustes", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Servidor API", fontWeight = FontWeight.Bold)
        OutlinedTextField(url, { url = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(onClick = { Api.baseUrl = url.trim(); save(Api.baseUrl) }, modifier = Modifier.fillMaxWidth()) { Text("Guardar servidor") }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("XerezTap Panel 2.0", fontWeight = FontWeight.Bold); Text("Gestión de negocios, QR, NFC y estadísticas.", color = Color.Gray) } }
    }
}
